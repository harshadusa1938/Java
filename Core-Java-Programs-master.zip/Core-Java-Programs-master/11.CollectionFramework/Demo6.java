import java.util.*;

class Demo6 
{
	public static void main(String[] args) 
	{
		List<int> al = new List<int>();
		al.Add(10);
	}
}
