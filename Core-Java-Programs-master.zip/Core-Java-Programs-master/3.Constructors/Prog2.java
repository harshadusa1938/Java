class Prog2 
{
	Prog2()
	{
		System.out.println("Constructor Invoked!!! \n");
	}
	public static void main(String[] args) 
	{		
		Prog2 obj = new Prog2();
		new Prog2();
	}
}
