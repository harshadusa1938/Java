import MyPackage.PackageDemo1;
class PackageDemo2 
{
	public static void main(String[] args) 
	{
		PackageDemo1 obj = new PackageDemo1();
		obj.MyMethod();
	}
}
