package MyPackage;
public class PackageDemo1 
{
	public void MyMethod()
	{
		System.out.println("MyMethod() from PackageDemo1 Class of MyPackage.");
	}
}

/*
To Compile the above Program:
1. Open Command Prompt, and go to the path of the above Program.
2. compile tha above program using the following command:
	Sysntax:
	javac -d . FileName.java

	Example:
	javac -d . PackageDemo1.java
*/