import java.lang.*;
class Demo1
{
   public static void main(String[] s)
   {
	int a = 25;
	char b = '@';
	float c = 12.36f;
	double d = 45.56;
	boolean e = true;
	String f = "Welcome";

	System.out.println("a = " + a + "\nb = " + b + "\nc = " + c);
	System.out.println("d = " + d + "\ne = " + e + "\nf = " + f);
   }
}